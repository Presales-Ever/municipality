import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-active-requests',
  templateUrl: './active-requests.component.html',
  styleUrls: ['./active-requests.component.css']
})
export class ActiveRequestsComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
