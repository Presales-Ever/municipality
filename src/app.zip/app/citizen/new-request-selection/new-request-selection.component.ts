import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-request-selection',
  templateUrl: './new-request-selection.component.html',
  styleUrls: ['./new-request-selection.component.scss'],
})
export class NewRequestSelectionComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
