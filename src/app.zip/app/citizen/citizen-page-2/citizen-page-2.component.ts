import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-citizen-page-2',
  templateUrl: './citizen-page-2.component.html',
  styleUrls: ['./citizen-page-2.component.css']
})
export class CitizenPage2Component implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
