import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-request-timeline',
  templateUrl: './request-timeline.component.html',
  styleUrls: ['./request-timeline.component.scss'],
})
export class RequestTimelineComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
