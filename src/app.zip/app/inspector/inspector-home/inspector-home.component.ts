import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-inspector-home',
  templateUrl: './inspector-home.component.html',
  styleUrls: ['./inspector-home.component.scss'],
})
export class InspectorHomeComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
