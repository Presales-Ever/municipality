import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-request-details',
  templateUrl: './new-request-details.component.html',
  styleUrls: ['./new-request-details.component.scss'],
})
export class NewRequestDetailsComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
