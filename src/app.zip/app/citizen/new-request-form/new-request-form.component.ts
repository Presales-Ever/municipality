import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-new-request-form',
  templateUrl: './new-request-form.component.html',
  styleUrls: ['./new-request-form.component.scss'],
})
export class NewRequestFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {}

}
